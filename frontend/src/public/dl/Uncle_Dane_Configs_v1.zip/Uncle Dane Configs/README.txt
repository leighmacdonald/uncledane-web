READ THIS CRAP BEFORE YOU DO ANYTHING PLEASE
////////////////////////////////////////////

Enclosed is a copy of Uncle Dane's TF2 configs as of 09/14/2020. 
These are being provided upon heavy request from viewers.
I highly recommend you use Notepad++ (a free software) to view these files.

IMPORTANT DISCLAIMER: UNLESS YOU WANT TO VERY LIKELY SCREW UP A BUNCH OF LITTLE
THINGS ABOUT YOUR CURRENT TF2 SETTINGS, DO NOT JUST REPLACE YOUR OWN AUTOEXEC
FILE WITH MINE. I AM PROVIDING THE AUTOEXEC AS A RESOURCE FOR YOU TO PULL IDEAS
FROM FOR WHAT YOU WOULD LIKE TO APPLY TO YOUR OWN CUSTOM AUTOEXEC. I HIGHLY 
SUGGEST YOU CREATE YOUR OWN CUSTOM CONFIG FROM SCRATCH USING CFG.TF AND BECOME
FAMILIAR WITH HOW TO READ/WRITE BASIC SCRIPTS IN TF2 (IF MY DUMB ASS CAN DO IT, 
SO CAN YOU.)

Here is a brief discription of each of the files provided. These files go in the
Steam/steamapps/common/Team Fortress 2/tf/cfg folder.

>> autoexec.cfg -- Contains most of, if not all of my custom binds and settings.
Do NOT copy and paste this into your cfg folder unless you REALLY want to use every
single one of my settings, which can possibly screw up a lot of your current settings.
>> engineer.cfg -- These settings will rebind certain keys to do certain things when
you pick Engineer in TF2. It contains my script for auto-building and auto-destroying
sentries, dispensers, and teleporters. It also contains Solarlight's Eureka Effect
teleporter script. Just so you know, it WILL take some time to get used to this, but I
think it's entirely worth it in the end.
>> logo.cfg -- This will print an image of the Uncle Dane logo to your console every
time the autoexec.cfg file is executed. It's mostly just to look cool, and to confirm
that everything is working alright.
>> viewmodel_script_OFF.cfg -- This is tied to a script I made in the autoexec which
is used to easily turn off and on viewmodels, as well as switch between different 
viewmodel FOVs by using the arrow keys. This turns everything off.
>> viewmodel_script_ON.cfg -- Same as above, except this turns everything on.

////////////////////////////////////////////

I cannot stress to you enough how much easier it will be to use the information in
these files if you take a bit of time to learn the basics of creating basic scripts in TF2.
Please do not ask Uncle Dane how to use these files, and do not request customer service
from him when it comes to errors or issues you may have when implementing these settings.
Uncle Dane is not an authority when it comes to TF2 scripting, and there are hundreds of
resources for you to pull from online when it comes to creating and troubleshooting TF2
scripts and configs.

I hope these files help in some way to make your game experience more fluid and enjoyable!
Thanks!


